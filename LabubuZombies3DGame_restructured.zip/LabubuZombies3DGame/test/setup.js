// Test setup
// Run tests with: node test/unit/config.test.js

console.log('Test setup loaded');
